from flask import Flask, jsonify, request, send_file, abort
import time
import jwt
import datetime
import os

app = Flask(__name__)

# ── JWT CONFIG ──────────────────────────────────────────────────────────────
JWT_SECRET = os.environ.get("JWT_SECRET", "super-secret-key-change-in-prod")
JWT_ALGORITHM = "HS256"
TOKEN_EXPIRY_MINUTES = 60

# ── SIMULATED USER STORE ────────────────────────────────────────────────────
USERS = {
    "angelo": {"role": "admin", "password": "demo123"},
    "Alex_Reyes": {"role": "admin", "password": "demo123"},
}

# Simulated session store (in production use Redis / DB)
SESSIONS = {}


def make_token(user: str, role: str, is_online: bool, session_id: str) -> str:
    """Sign a JWT with the user's current online status baked in."""
    payload = {
        "user": user,
        "role": role,
        "is_online": is_online,
        "session_id": session_id,
        "iat": datetime.datetime.utcnow(),
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=TOKEN_EXPIRY_MINUTES),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_token(token: str):
    """Decode and verify JWT. Returns payload dict or raises."""
    return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])


def get_bearer() -> str | None:
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:]
    return None


# ── PRE-AUTH TOKEN ──────────────────────────────────────────────────────────
# Issues an offline token so the client always has a valid (but locked) JWT.
@app.route("/api/preauth", methods=["POST"])
def preauth():
    """
    Body: { "user": "angelo" }
    Returns a signed JWT with is_online=false so the dashboard stays locked
    until the user explicitly checks in.
    """
    body = request.get_json(silent=True) or {}
    user = body.get("user", "")

    if user not in USERS:
        return jsonify({"error": "Unknown user"}), 404

    session_id = f"s_{os.urandom(5).hex()}"
    SESSIONS[user] = {
        "session_id": session_id,
        "is_online": False,
        "last_active": None,
    }

    token = make_token(user, USERS[user]["role"], is_online=False, session_id=session_id)
    return jsonify({
        "token": token,
        "message": "Pre-auth token issued. Check in to unlock dashboard.",
    })


# ── CHECK-IN ────────────────────────────────────────────────────────────────
@app.route("/api/checkin", methods=["POST"])
def checkin():
    """
    Requires valid Bearer token.
    Marks user online and returns a NEW token with is_online=true.
    """
    raw = get_bearer()
    if not raw:
        return jsonify({"error": "Missing Bearer token"}), 401

    try:
        claims = decode_token(raw)
    except jwt.ExpiredSignatureError:
        return jsonify({"error": "Token expired"}), 401
    except jwt.InvalidTokenError:
        return jsonify({"error": "Invalid token"}), 401

    user = claims["user"]
    session = SESSIONS.get(user)
    if not session:
        return jsonify({"error": "No session found. Request a pre-auth token first."}), 403

    # Update server-side session
    session["is_online"] = True
    session["last_active"] = time.time()

    # Issue new token with is_online=true
    new_token = make_token(user, claims["role"], is_online=True, session_id=session["session_id"])
    return jsonify({
        "token": new_token,
        "message": "Checked in. Dashboard unlocked.",
    })


# ── CHECK-OUT ───────────────────────────────────────────────────────────────
@app.route("/api/checkout", methods=["POST"])
def checkout():
    """Marks user offline, returns new locked token."""
    raw = get_bearer()
    if not raw:
        return jsonify({"error": "Missing Bearer token"}), 401

    try:
        claims = decode_token(raw)
    except jwt.InvalidTokenError:
        return jsonify({"error": "Invalid token"}), 401

    user = claims["user"]
    session = SESSIONS.get(user)
    if session:
        session["is_online"] = False
        session["last_active"] = None

    locked_token = make_token(user, claims["role"], is_online=False, session_id=claims["session_id"])
    return jsonify({
        "token": locked_token,
        "message": "Checked out. Dashboard locked.",
    })


# ── STATUS ──────────────────────────────────────────────────────────────────
@app.route("/api/status")
def api_status():
    """
    Requires valid Bearer token.
    Returns status derived from the SIGNED token — not from a query param
    or anything the client can forge.
    """
    raw = get_bearer()
    if not raw:
        return jsonify({"error": "Missing Bearer token", "token_valid": False}), 401

    try:
        claims = decode_token(raw)
    except jwt.ExpiredSignatureError:
        return jsonify({"error": "Token expired", "token_valid": False}), 401
    except jwt.InvalidTokenError:
        return jsonify({"error": "Invalid token", "token_valid": False}), 401

    # Cross-check against server-side session (defence in depth)
    session = SESSIONS.get(claims["user"], {})
    server_online = session.get("is_online", False)

    # Both the token claim AND the server session must agree
    is_online = claims.get("is_online", False) and server_online

    return jsonify({
        "user": claims["user"],
        "role": claims["role"],
        "is_online": is_online,
        "session_id": claims["session_id"],
        "token_valid": True,
    })


# ── PROTECTED DASHBOARD ─────────────────────────────────────────────────────
@app.route("/dashboard")
def dashboard():
    """
    Server-side protected route.
    Returns 423 Locked if the token says is_online=false.
    """
    raw = get_bearer()
    if not raw:
        return jsonify({"error": "Authentication required", "locked": True}), 401

    try:
        claims = decode_token(raw)
    except jwt.InvalidTokenError:
        return jsonify({"error": "Invalid or expired token", "locked": True}), 401

    session = SESSIONS.get(claims["user"], {})
    if not claims.get("is_online") or not session.get("is_online"):
        return jsonify({
            "error": "Dashboard locked. Check in first.",
            "locked": True,
            "user": claims["user"],
        }), 423  # 423 Locked

    # ✅ Unlocked — return sensitive data
    return jsonify({
        "locked": False,
        "user": claims["user"],
        "role": claims["role"],
        "internal_api_key": "sk-prod-8f2k9xLmR7Tq...",
        "db_host": "prod-db.internal:5432",
        "admin_users": 3,
    })


@app.route("/")
def home():
    return send_file("resp.html")


if __name__ == "__main__":
    print("[*] SecureVault running on http://localhost:3000")
    print("[*] Endpoints:")
    print("    POST /api/preauth   — get offline token")
    print("    POST /api/checkin   — check in (requires token)")
    print("    POST /api/checkout  — check out (requires token)")
    print("    GET  /api/status    — session status (requires token)")
    print("    GET  /dashboard     — protected resource (requires online token)")
    app.run(host="0.0.0.0", port=3000, debug=True)