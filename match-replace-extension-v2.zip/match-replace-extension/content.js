// content.js — runs in MAIN world at document_start
// Runs directly in the page's JS context before any page scripts load.

(function () {
  'use strict';

  const STORAGE_KEY = '__match_replace_rules__';
  const ENABLED_KEY = '__match_replace_enabled__';

  function getRules() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); }
    catch { return []; }
  }

  function isEnabled() {
    return localStorage.getItem(ENABLED_KEY) !== 'false';
  }

  function applyRules(text, url) {
    if (!isEnabled() || !text || typeof text !== 'string') return text;
    const rules = getRules();
    let out = text;
    for (const rule of rules) {
      if (!rule.enabled || !rule.match) continue;
      try {
        const before = out;
        out = out.split(rule.match).join(rule.replace || '');
        if (out !== before) {
          window.dispatchEvent(new CustomEvent('__mr_match__', {
            detail: { url, match: rule.match, replace: rule.replace, description: rule.description }
          }));
        }
      } catch (e) {}
    }
    return out;
  }

  // ── Patch fetch ──────────────────────────────────────────────────────────
  const _fetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await _fetch.apply(this, args);
    if (!isEnabled()) return response;
    const url = args[0] instanceof Request ? args[0].url : String(args[0] || '');
    const ct = response.headers.get('content-type') || '';
    if (!ct.includes('json') && !ct.includes('text')) return response;
    try {
      const original = await response.clone().text();
      const modified = applyRules(original, url);
      if (modified === original) return response;
      return new Response(modified, {
        status: response.status,
        statusText: response.statusText,
        headers: response.headers
      });
    } catch (e) { return response; }
  };

  // ── Patch XHR ────────────────────────────────────────────────────────────
  const _XHR = window.XMLHttpRequest;
  const _open = _XHR.prototype.open;
  const _send = _XHR.prototype.send;

  _XHR.prototype.open = function (method, url, ...rest) {
    this._mrUrl = url;
    return _open.call(this, method, url, ...rest);
  };

  _XHR.prototype.send = function (body) {
    this.addEventListener('readystatechange', function () {
      if (this.readyState !== 4 || this.__mr_done__) return;
      this.__mr_done__ = true;
      try {
        const ct = this.getResponseHeader('content-type') || '';
        if (!ct.includes('json') && !ct.includes('text')) return;
        const nativeDesc = Object.getOwnPropertyDescriptor(_XHR.prototype, 'responseText');
        const original = nativeDesc ? nativeDesc.get.call(this) : null;
        if (!original) return;
        const modified = applyRules(original, this._mrUrl || this.responseURL || '');
        if (modified === original) return;
        Object.defineProperty(this, 'responseText', { get: () => modified, configurable: true });
        Object.defineProperty(this, 'response', { get: () => modified, configurable: true });
      } catch (e) {}
    }, false);
    return _send.call(this, body);
  };

  console.log('[Match & Replace v2] Active in MAIN world.');
})();
