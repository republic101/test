// bridge.js — runs in ISOLATED world (default)
// Syncs chrome.storage rules into localStorage so the MAIN world content script can read them.

const STORAGE_KEY = '__match_replace_rules__';
const ENABLED_KEY = '__match_replace_enabled__';

function syncToPage() {
  chrome.storage.local.get(['rules', 'extensionEnabled'], (data) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data.rules || []));
    localStorage.setItem(ENABLED_KEY, data.extensionEnabled !== false ? 'true' : 'false');
  });
}

// Sync immediately on load
syncToPage();

// Re-sync whenever storage changes (e.g. user saves rules in popup)
chrome.storage.onChanged.addListener(() => syncToPage());

// Listen for match events from MAIN world and forward to background for logging
window.addEventListener('__mr_match__', (e) => {
  chrome.runtime.sendMessage({ type: 'LOG_MATCH', data: e.detail });
});
