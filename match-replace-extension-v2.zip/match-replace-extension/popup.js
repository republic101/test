// popup.js
let rules = [];
let extensionEnabled = true;

// ─── Init ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadAll();
  bindTabs();
  bindMasterToggle();
  document.getElementById('addRuleBtn').addEventListener('click', addRule);
  document.getElementById('saveBtn').addEventListener('click', saveRules);
  document.getElementById('clearLogBtn').addEventListener('click', clearLog);
});

function loadAll() {
  chrome.runtime.sendMessage({ type: 'GET_RULES' }, (res) => {
    if (!res) return;
    rules = res.rules || [];
    extensionEnabled = res.enabled !== false;
    document.getElementById('masterToggle').checked = extensionEnabled;
    document.getElementById('toggleLabel').textContent = extensionEnabled ? 'ON' : 'OFF';
    renderRules();
  });
  loadLog();
}

// ─── Tabs ─────────────────────────────────────────────────────────────────────
function bindTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById('panel-' + tab.dataset.tab).classList.add('active');
      if (tab.dataset.tab === 'log') loadLog();
    });
  });
}

// ─── Master Toggle ────────────────────────────────────────────────────────────
function bindMasterToggle() {
  document.getElementById('masterToggle').addEventListener('change', (e) => {
    extensionEnabled = e.target.checked;
    document.getElementById('toggleLabel').textContent = extensionEnabled ? 'ON' : 'OFF';
    chrome.runtime.sendMessage({ type: 'TOGGLE_EXTENSION', enabled: extensionEnabled });
  });
}

// ─── Rules Rendering ──────────────────────────────────────────────────────────
function renderRules() {
  const list = document.getElementById('rulesList');
  list.innerHTML = '';

  if (rules.length === 0) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">🔍</div><p>No rules yet. Add one below.</p></div>';
    return;
  }

  rules.forEach((rule, idx) => {
    const card = document.createElement('div');
    card.className = 'rule-card' + (rule.enabled ? '' : ' disabled');
    card.innerHTML = `
      <div class="rule-header">
        <input class="rule-desc" type="text" placeholder="Rule description…" value="${escHtml(rule.description || '')}" data-idx="${idx}" data-field="description" />
        <div class="rule-actions">
          <button class="btn-icon toggle-rule" title="${rule.enabled ? 'Disable' : 'Enable'}" data-idx="${idx}">
            ${rule.enabled ? '●' : '○'}
          </button>
          <button class="btn-icon delete-rule" title="Delete rule" data-idx="${idx}">✕</button>
        </div>
      </div>
      <div class="rule-fields">
        <div class="field-row">
          <span class="field-tag">Find</span>
          <input class="match-input" type="text" placeholder='"is_online":false' value="${escHtml(rule.match || '')}" data-idx="${idx}" data-field="match" />
        </div>
        <div class="field-row">
          <span class="field-tag">Replace</span>
          <input class="replace-input" type="text" placeholder='"is_online":true' value="${escHtml(rule.replace || '')}" data-idx="${idx}" data-field="replace" />
        </div>
      </div>
    `;

    // Bind field inputs
    card.querySelectorAll('input').forEach(input => {
      input.addEventListener('input', (e) => {
        const i = parseInt(e.target.dataset.idx);
        const field = e.target.dataset.field;
        if (field) rules[i][field] = e.target.value;
      });
    });

    // Toggle
    card.querySelector('.toggle-rule').addEventListener('click', (e) => {
      const i = parseInt(e.currentTarget.dataset.idx);
      rules[i].enabled = !rules[i].enabled;
      renderRules();
    });

    // Delete
    card.querySelector('.delete-rule').addEventListener('click', (e) => {
      const i = parseInt(e.currentTarget.dataset.idx);
      rules.splice(i, 1);
      renderRules();
    });

    list.appendChild(card);
  });
}

function addRule() {
  rules.push({
    id: Date.now(),
    enabled: true,
    description: '',
    match: '',
    replace: ''
  });
  renderRules();
  // Scroll to bottom
  document.getElementById('rulesList').lastElementChild?.scrollIntoView({ behavior: 'smooth' });
}

function saveRules() {
  chrome.runtime.sendMessage({ type: 'SAVE_RULES', rules }, () => {
    const msg = document.getElementById('statusMsg');
    msg.classList.add('show');
    setTimeout(() => msg.classList.remove('show'), 2000);
  });
}

// ─── Log ──────────────────────────────────────────────────────────────────────
function loadLog() {
  chrome.storage.local.get(['matchLog'], (data) => {
    const log = data.matchLog || [];
    renderLog(log);
    document.getElementById('logBadge').textContent = log.length;
  });
}

function renderLog(log) {
  const list = document.getElementById('logList');
  list.innerHTML = '';

  if (log.length === 0) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><p>No matches yet.<br/>Browse pages with active rules.</p></div>';
    return;
  }

  log.forEach(entry => {
    const item = document.createElement('div');
    item.className = 'log-item';
    const time = new Date(entry.timestamp).toLocaleTimeString();
    const urlShort = entry.url ? entry.url.replace(/^https?:\/\//, '').slice(0, 55) : '—';
    item.innerHTML = `
      <div class="log-url" title="${escHtml(entry.url || '')}">${escHtml(urlShort)}</div>
      <div class="log-change">
        <span class="log-match">${escHtml(entry.match || '')}</span>
        <span class="log-arrow">→</span>
        <span class="log-replace">${escHtml(entry.replace || '')}</span>
      </div>
      <div class="log-time">${escHtml(entry.description || 'Rule')} · ${time}</div>
    `;
    list.appendChild(item);
  });
}

function clearLog() {
  chrome.storage.local.set({ matchLog: [] }, () => {
    renderLog([]);
    document.getElementById('logBadge').textContent = '0';
  });
}

// ─── Utils ────────────────────────────────────────────────────────────────────
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
