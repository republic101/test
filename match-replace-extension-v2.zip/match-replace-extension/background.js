// Background service worker

chrome.runtime.onInstalled.addListener(() => {
  const defaultRules = [
    {
      id: 1,
      enabled: true,
      match: '"is_online":false',
      replace: '"is_online":true',
      description: 'Force is_online to true'
    }
  ];
  chrome.storage.local.set({ rules: defaultRules, extensionEnabled: true });

  // Inject bridge into all existing tabs immediately
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (tab.id && tab.url && !tab.url.startsWith('chrome://')) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          files: ['bridge.js'],
          world: 'ISOLATED'
        }).catch(() => {});
      }
    }
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_RULES') {
    chrome.storage.local.get(['rules', 'extensionEnabled'], (data) => {
      sendResponse({ rules: data.rules || [], enabled: data.extensionEnabled !== false });
    });
    return true;
  }

  if (message.type === 'SAVE_RULES') {
    chrome.storage.local.set({ rules: message.rules }, () => {
      sendResponse({ success: true });
      // Push updated rules to all open tabs
      chrome.tabs.query({}, (tabs) => {
        for (const tab of tabs) {
          if (tab.id && tab.url && !tab.url.startsWith('chrome://')) {
            chrome.scripting.executeScript({
              target: { tabId: tab.id, allFrames: true },
              files: ['bridge.js'],
              world: 'ISOLATED'
            }).catch(() => {});
          }
        }
      });
    });
    return true;
  }

  if (message.type === 'TOGGLE_EXTENSION') {
    chrome.storage.local.set({ extensionEnabled: message.enabled }, () => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'LOG_MATCH') {
    chrome.storage.local.get(['matchLog'], (data) => {
      const log = data.matchLog || [];
      log.unshift({ ...message.data, timestamp: new Date().toISOString() });
      chrome.storage.local.set({ matchLog: log.slice(0, 50) });
    });
  }
});
